using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class InputManager : MonoBehaviour
{
    private Transform[] transArray;
    [SerializeField]float redPosition_y;
    [SerializeField]float bluePosition_y;
    // Start is called before the first frame update
    void Start()
    {
        transArray = new Transform[2];
        transArray[0] = GameObject.FindWithTag("Red").transform;
        transArray[1] = GameObject.FindWithTag("Blue").transform;

        redPosition_y = transArray[0].position.y;
        bluePosition_y = transArray[1].position.y;

    }

    // Update is called once per frame
    void Update()
    {
        GameObject redp = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(go => go.CompareTag("Red"));
        GameObject bluep = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(go => go.CompareTag("Blue"));
        if (Input.GetKeyDown(KeyCode.W))
        {
            if (redp)
            {
                redp.transform.Rotate(0, 0, 45);
            }
            if (bluep)
                bluep.transform.Rotate(0, 0, -45);
        }

        

 
        if (Input.GetButtonDown("Fire1"))
        {
            Vector3 redpP = transArray[0].position;
            Vector3 bluepP = transArray[1].position;


            if (redp)
            {
                redp.transform.position = new Vector3(redpP.x, bluePosition_y, redpP.z);
            }
            if(bluep)
            {
                bluep.transform.position = new Vector3(bluepP.x, redPosition_y, bluepP.z);
            }

            //swap
            float swap = redPosition_y;
            redPosition_y = bluePosition_y;
            bluePosition_y = swap;
        }



        if (Input.GetButtonUp("Fire1"))
        {
            if (redp)
            {
                if (redp.GetComponent<PrintAndHide>() != null)
                {
                    if (redp.GetComponent<PrintAndHide>().rend != null)
                    {
                        int randValue = Random.Range(51, 251);
                        redp.GetComponent<PrintAndHide>().rend.material.color = new Color(randValue / 255f,0.0f,0.0f);

                        Debug.Log("Red" + redp.GetComponent<PrintAndHide>().rend.material.color);
                    }
                }

                if (bluep)
                {
                    if (bluep.GetComponent<PrintAndHide>() != null)
                    {
                        if (bluep.GetComponent<PrintAndHide>().rend != null)
                        {
                            int randValue = Random.Range(51, 251);
                            bluep.GetComponent<PrintAndHide>().rend.material.color = new Color(0.0f, 0.0f, randValue / 255f);

                            Debug.Log("Blue" + bluep.GetComponent<PrintAndHide>().rend.material.color);
                        }
                    }
                }
            }
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            if (redp != null)
            {
                if (redp.GetComponent<PrintAndHide>() != null)
                {
                    Destroy(redp.GetComponent<PrintAndHide>());
                }
                else
                {
                    redp.AddComponent<PrintAndHide>();
                    redp.SetActive(true);

                }
            }
            if (bluep != null)
            {
                if (bluep.GetComponent<PrintAndHide>() != null)
                {
                    Destroy(bluep.GetComponent<PrintAndHide>());
                }
                else
                {
                    bluep.AddComponent<PrintAndHide>();
                    bluep.SetActive(true);
                }
            }
        }
    }
}
