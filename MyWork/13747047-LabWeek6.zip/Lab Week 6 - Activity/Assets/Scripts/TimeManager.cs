﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class TimeManager : MonoBehaviour
{
    private int lastTime = 0;
    private float timer = 0.0f;
    private bool pause = false;
    [SerializeField] private Transform[] transformArray;
    const float moveWait = 2.0f;
    private Vector3[] positions = { new Vector3(2, 1, 0),  new Vector3(2, -1, 0), new Vector3(-2, -1, 0), new Vector3(-2, 1, 0) };
    const float scaleWait = 4.0f;

    private void Start()
    {
        Camera.main.orthographic = true;
        Camera.main.orthographicSize = 2;
        ResetTime();

    }

    private void MoveOjects()
    {
        if ((lastTime - 1) % moveWait == 0.0 && (lastTime - 1) >= moveWait)
        {
            for (int i = 0; i < transformArray.Length; i++)
            {

                int index = Array.IndexOf(positions, transformArray[i].position);

                if (index + 1 >=positions.Length)
                {
                    index = -1;
                }
                transformArray[i].position = positions[index + 1];
            }
        }

    }

    private void ScaleObjects()
    {
        for (int i = 0; i < transformArray.Length; i++)
        {
            if (transformArray[i].localScale.x > 1.5)
            {
                transformArray[i].localScale = transformArray[i].localScale / 1.2f;
            }
            else
            {
                transformArray[i].localScale = transformArray[i].localScale * 1.2f;
            }
        }
    }



    private void Update()
    {
        //50%
        if (Input.GetKeyDown(KeyCode.Space))
        {

            pause = !pause;
            Time.timeScale = Convert.ToInt32(!pause);
            Debug.Log("Spacebar pressed");

            CancelInvoke("ScaleObjects");
        }


        //60%


        //Debug.Log("lasttime" + lastTime);
        //Debug.Log("int timer" + (int)timer);
        
        timer += Time.deltaTime;
        if (timer - lastTime >= 1f)
        {
            lastTime = (int)timer;
            
            Debug.Log(lastTime - 1);

            MoveOjects();
        }
        
        //Debug.Log(lastTime);


        if (Input.GetKeyDown(KeyCode.Return))
        {
            ResetTime();
        }

        //40%
        //if (lastTime <= Time.time - 1f)
        //{
        //    lastTime = (int)Time.time;
        //    Debug.Log(lastTime);
        //}


        

        if(Input.GetKeyDown(KeyCode.Escape))
        {
            float randomValue = UnityEngine.Random.Range(0.25f, 0.75f);
            StartCoroutine("RotateObjects", randomValue);
        }
    }

    private void ResetTime()
    {
        timer = 0;
        lastTime = 0;
        InvokeRepeating("ScaleObjects", 0.0f, scaleWait);
    }






    IEnumerable RotateObjects(float randomDelay)
    {
        yield return new WaitForSeconds(randomDelay);
        for (int i = 0; i < transformArray.Length; i++)
        {
            transformArray[i].Rotate(Vector3.forward, 90);
        }

        for (int j = 0; j < 3; j++)
        {
            
        }
    }
}


