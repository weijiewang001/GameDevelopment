using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    [SerializeField] private GameObject item;
    private Tweener tweener;
    private List<GameObject> itemList;

    void Start()
    {
        tweener = GetComponent<Tweener>();
        //100
        itemList = new List<GameObject>();
        itemList.Add(item);
    }

    // Update is called once per frame
    void Update()

    {
        if (Input.GetKeyDown(KeyCode.A)){
            tweener.AddTween(item.transform, item.transform.position, new Vector3(-2.0f, 0.5f, 0.0f), 1.5f);
            //100
            LoopItemListnAddTween(new Vector3(-2.0f, 0.5f, 0.0f), 1.5f);
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            tweener.AddTween(item.transform, item.transform.position, new Vector3(2.0f, 0.5f, 0.0f), 1.5f);
            LoopItemListnAddTween(new Vector3(2.0f, 0.5f, 0.0f), 1.5f);
        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            tweener.AddTween(item.transform, item.transform.position, new Vector3(0f, 0.5f, -2.0f), 0.5f);
            LoopItemListnAddTween(new Vector3(0f, 0.5f, -2.0f), 0.5f);
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            tweener.AddTween(item.transform, item.transform.position, new Vector3(0f, 0.5f, 2.0f), 0.5f);
            LoopItemListnAddTween(new Vector3(0f, 0.5f, 2.0f), 0.5f);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            itemList.Add(Instantiate(item, new Vector3(0, 0.5f, 0), Quaternion.identity));
        }
    }


    //100
    void LoopItemListnAddTween(Vector3 endPos, float duration)
    {
        foreach (GameObject item in itemList)
        {
            bool result = tweener.AddTween(item.transform, item.transform.position, endPos, duration);
            if (result)
            {
                break;
            }
            else
            {

            }
        }
    }
}
