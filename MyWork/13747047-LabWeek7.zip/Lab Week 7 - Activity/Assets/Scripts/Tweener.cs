using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tweener : MonoBehaviour
{
    //private Tween activeTween;
    private List<Tween> activeTweens = new List<Tween>();



    // Update is called once per frame
    void Update()
    {


        foreach (Tween item in activeTweens)
        {
            RemoveTween(item);
        }
        



        
    }

    public void RemoveTween(Tween activeTween)
    {
        float distance = Vector3.Distance(activeTween.Target.position, activeTween.EndPos);
        if (distance > 0.1f)
        {
            float fractionTime = (Time.time - activeTween.StartTime) / activeTween.Duration;
            //activeTween.Target.position = Vector3.Lerp(activeTween.StartPos, activeTween.EndPos, fractionTime);
            activeTween.Target.position = Coserp(activeTween.StartPos, activeTween.EndPos, fractionTime);

        }
        if (distance <= 0.1f)
        {
            activeTween.Target.position = activeTween.EndPos;
            activeTween = null;
        }
    }

    //public void AddTween(Transform targetObject, Vector3 startPos, Vector3 endPos, float duration)
    //{
    //    if (activeTween == null)
    //    {
    //        activeTween = new Tween(targetObject, startPos, endPos, Time.time, duration);
    //    }
    //else
    //{
    //    activeTween = new Tween(targetObject, startPos, endPos, Time.time, duration);
    //}
    //}

    public static float EaseInCubic(float start, float end, float value)
    {
        end -= start;
        return end * value * value * value + start;
    }

    //90
    //refer from http://wiki.unity3d.com/index.php?title=Mathfx#C.23_-_Mathfx.cs
    public static float Coserp(float start, float end, float value)
    {
        return Mathf.Lerp(start, end, 1.0f - Mathf.Cos(value * Mathf.PI * 0.5f));
    }

    public static Vector3 Coserp(Vector3 start, Vector3 end, float value)
    {
        return new Vector3(Coserp(start.x, end.x, value), Coserp(start.y, end.y, value), Coserp(start.z, end.z, value));
    }




    //100
    public bool TweenExists(Transform target)
    {
        foreach (Tween i in activeTweens)
        {
            if (i.Target == target)
            {
                return true;
            }
        }

        return false;
    }

    public bool AddTween(Transform targetObject, Vector3 startPos, Vector3 endPos, float duration)
    {
        if (!TweenExists(targetObject))
        {
            activeTweens.Add(new Tween(targetObject, startPos, endPos,Time.time, duration));
            return true;
        }
        else
        {
            return false;
        }
        
    }
}
