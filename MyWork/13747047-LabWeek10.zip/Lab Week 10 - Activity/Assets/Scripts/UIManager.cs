using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{

    private Image inHealthBar;
    private Transform playerTransform;
    private float speed = 10.0f;
    void Start()
    {
        DontDestroyOnLoad(gameObject);
    }

    void Update()
    {
        if (playerTransform != null)
        {
            float healthNumber = Mathf.Clamp(Mathf.Abs(playerTransform.position.x), 0.0f, 5.0f);
            float healValue = 1 - 1 / 5.0f * healthNumber;
            inHealthBar.fillAmount = healValue;
            if (healValue < 0.5f)
            {
                inHealthBar.color = Color.red;
            }
            if (healValue > 0.5f)
            {
                inHealthBar.color = Color.green;
            }
        }

        if (Input.GetKey(KeyCode.J))
        {
            Camera.main.transform.Rotate(Vector3.down * speed * Time.deltaTime, Space.World);
        }

        if (Input.GetKey(KeyCode.L))
        {

            Camera.main.transform.Rotate(Vector3.up * speed * Time.deltaTime, Space.World);
        }
    }

    

    public void LoadFirstLevel()
    {
        SceneManager.LoadScene(0);
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    public void QuitGame()
    {
        UnityEditor.EditorApplication.isPlaying = false;
    }

    public void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.buildIndex >= 0)
        {
            Button quitButton = GameObject.FindGameObjectWithTag("QuitButton").GetComponent<Button>();
            quitButton.onClick.AddListener(QuitGame);

            inHealthBar = GameObject.FindGameObjectWithTag("PlayerHealthBar").GetComponent<Image>();
            playerTransform = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();

        }
    }
}
