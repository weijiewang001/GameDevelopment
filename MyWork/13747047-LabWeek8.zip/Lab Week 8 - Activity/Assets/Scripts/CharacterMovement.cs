using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour
{
    private Vector3 movement;
    private float movementSqrMagnitude;
    public float walkSpeed = 1.75f;
    public Animator moveAnimator;
    public AudioSource footStepSource;
    public AudioClip[] footStepClips;
    public AudioSource backgroundMusic;



    void Update()
    {
        GetMovementInput();
        RaycastCheck();
        CharacterPostion();
        CharacterRotation();
        WalkingAnimation();
        FootstepAudio();



    }

    void GetMovementInput()
    {
        movement.x = Input.GetAxis("Horizontal");
        movement.z = Input.GetAxis("Vertical");
        movementSqrMagnitude = movement.sqrMagnitude;
        //Debug.Log(movement);
        movement = Vector3.ClampMagnitude(movement, 1.0f);
    }

    void CharacterPostion()
    {
        transform.Translate(movement * walkSpeed * Time.deltaTime, Space.World);
    }

    void CharacterRotation()
    {
        if (movement != Vector3.zero)
        {
            Quaternion rotation = Quaternion.LookRotation(movement);
            transform.rotation = rotation;
        }

    }

    void WalkingAnimation()
    {
        moveAnimator = GetComponent<Animator>();
        moveAnimator.SetFloat("MoveSpeed", movementSqrMagnitude);
    }

    void FootstepAudio()
    {
        if (movementSqrMagnitude > 0.25f && !footStepSource.isPlaying)
        {
            if (footStepSource.clip.Equals(footStepClips[0]))
            {
                footStepSource.clip = footStepClips[1];
            }
            else if (footStepSource.clip.Equals(footStepClips[1]))
            {
                footStepSource.clip = footStepClips[0];
            }

            //Set the volume of the audio source to the movementSqrMagnitude variable.
            footStepSource.volume = movementSqrMagnitude;
            footStepSource.Play();

            //“Duck” the background music volume by reducing it to 0.5f.
            backgroundMusic.volume = 0.5f;

        }
        else if (movementSqrMagnitude <= 0.3f && footStepSource.isPlaying)
        {
            footStepSource.Stop();
            backgroundMusic.volume = 1.0f;
        }
    }

    //trigger after player's collider leave the cube's collier
    private void OnTriggerExit(Collider collider)
    {
        Debug.Log("Trigger Exit: " + collider.gameObject.name + " : " + collider.gameObject.transform.position);
    }

    //trigger once player's collider touch the the scope of cube's collier
    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("Collision Enter: " + collision.collider.gameObject.name + " : " + collision.contacts[0].point);
    }


    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.transform.tag == "Impassable")
        {
            Debug.Log("Collision Stay: " + collision.collider.gameObject.name);
        }
    }

    private bool RaycastCheck()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position + new Vector3(0f, 1.0f, 0f), transform.forward, out hit, 5))
        {
            Debug.Log("Raycast Hit: " + hit.collider.name);
            if (hit.collider.CompareTag("Freeze"))
            {
                Freeze();
                return true;
            }
        }
        return false;
    }

    void Freeze()
    {
        if (movement != Vector3.zero)
        { 
            if (Quaternion.Angle(Quaternion.LookRotation(movement), transform.rotation) == 0)
            {
                movement = Vector3.zero;
                movementSqrMagnitude = 0f;
            }
        }
    }
}
