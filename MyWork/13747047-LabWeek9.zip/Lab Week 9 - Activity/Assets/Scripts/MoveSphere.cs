using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveSphere : MonoBehaviour
{
    private Vector3 target = new Vector3(-3f, 1f, 0f);
    private float duration = 1.5f;
    public Tweener tweener;


    void Start()
    {

    }

    void Update()
    {
        if (!tweener.TweenExists(transform))
        {
            target.x = -target.x;
            tweener.AddTween(transform, transform.position, target, duration / SpeedManager.SpeedModifier);
        }
    }
}

