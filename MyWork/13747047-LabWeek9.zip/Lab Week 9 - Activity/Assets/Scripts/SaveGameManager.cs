using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveGameManager : MonoBehaviour
{
    const string saveKey = "Save Speed";

    void Start()
    {
        LoadSpeedState();

    }

    void Update()
    {

    }

    public void SaveSpeed()
    {
        int saveValue = (int)SpeedManager.CurrentSpeedState;
        int loadValue = PlayerPrefs.GetInt(saveKey);
        if (!saveValue.Equals(loadValue))
        {
            PlayerPrefs.SetInt(saveKey, saveValue);
            PlayerPrefs.Save();

        }
    }

    public void LoadSpeedState()
    {
        SpeedManager.CurrentSpeedState = (SpeedManager.GameSpeed)PlayerPrefs.GetInt(saveKey);
    }
}
